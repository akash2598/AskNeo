export const Images = {
    commingSoon: require('./comming_soon.png'),
};
